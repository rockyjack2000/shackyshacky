#!/bin/bash
python3 cmd/main.py
